/* 
/ Bool.h
/ Created by Ramírez Castañón Jorge Francisco
/ 17/05/17
*/

#ifndef Bool_h
#define Bool_h

/**
 * Define las variables tipo booleano
 */
enum {FALSE = 0, TRUE = !0};
typedef unsigned int Bool;

#endif /* Bool_h */